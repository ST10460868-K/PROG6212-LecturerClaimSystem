﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ContractClaimSystem.Data;
using ContractClaimSystem.Models;
using System.Security.Claims;

namespace ContractClaimSystem.Controllers
{
    [Authorize] // All dashboards require login
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        // LECTURER DASHBOARD (Separate Page: Submit Claims)
        [Authorize(Roles = "Lecturer")]
        public IActionResult Lecturer()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var claims = _context.Claims.Where(c => c.LecturerName == userId).ToList(); // Show user's claims
            ViewBag.UserClaims = claims;
            return View();
        }

        [HttpPost]
        [Authorize(Roles = "Lecturer")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitClaim(Claim claim, IFormFile[] documents)
        {
            if (!ModelState.IsValid) return View("Lecturer", claim);

            // File Upload & Validation
            var validDocs = new List<string>();
            var allowedTypes = new[] { ".pdf", ".docx", ".png", ".jpg", ".jpeg" };
            if (documents != null)
            {
                foreach (var doc in documents)
                {
                    if (allowedTypes.Any(t => doc.FileName.EndsWith(t, StringComparison.OrdinalIgnoreCase)))
                    {
                        var fileName = Path.GetFileName(doc.FileName);
                        var path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads", fileName);
                        using (var stream = new FileStream(path, FileMode.Create))
                            await doc.CopyToAsync(stream);
                        validDocs.Add(fileName);
                    }
                }
            }
            if (validDocs.Count == 0)
                ModelState.AddModelError("Documents", "At least one valid document required");

            if (!ModelState.IsValid) return View("Lecturer", claim);

            claim.Documents = validDocs.ToArray();
            claim.LecturerName = User.FindFirstValue(ClaimTypes.Name); // Auto-set from login
            claim.ApprovalNote = claim.TotalAmount <= 5000 ? "Auto-eligible for approval" : "Pending manual review";

            _context.Claims.Add(claim);
            await _context.SaveChangesAsync();

            TempData["Success"] = $"Claim submitted! Total: R{claim.TotalAmount:F2} | Status: {claim.Status}";
            return RedirectToAction("Lecturer");
        }

        // PC DASHBOARD (Separate Page: Verify & Approve Pending Claims)
        [Authorize(Roles = "ProgrammeCoordinator")]
        public async Task<IActionResult> PC()
        {
            var pendingClaims = await _context.Claims.Where(c => c.Status == "Pending").ToListAsync();
            return View(pendingClaims);
        }

        [HttpPost]
        [Authorize(Roles = "ProgrammeCoordinator")]
        public async Task<IActionResult> ApprovePC(int id, string comment)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            claim.Status = "PC Approved";
            claim.ApprovalNote += $"\nPC Comment: {comment}";
            await _context.SaveChangesAsync();

            TempData["Success"] = "Claim approved!";
            return RedirectToAction("PC");
        }

        [HttpPost]
        [Authorize(Roles = "ProgrammeCoordinator")]
        public async Task<IActionResult> RejectPC(int id, string comment)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            claim.Status = "Rejected";
            claim.ApprovalNote += $"\nPC Rejection: {comment}";
            await _context.SaveChangesAsync();

            TempData["Success"] = "Claim rejected.";
            return RedirectToAction("PC");
        }

        // PM DASHBOARD (Separate Page: Final Approval for PC-Approved Claims)
        [Authorize(Roles = "AcademicManager")]
        public async Task<IActionResult> PM()
        {
            var pcApprovedClaims = await _context.Claims.Where(c => c.Status == "PC Approved").ToListAsync();
            return View(pcApprovedClaims);
        }

        [HttpPost]
        [Authorize(Roles = "AcademicManager")]
        public async Task<IActionResult> ApprovePM(int id, string comment)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            claim.Status = "PM Approved";
            claim.ApprovalNote += $"\nPM Comment: {comment}";
            await _context.SaveChangesAsync();

            TempData["Success"] = "Final approval granted!";
            return RedirectToAction("PM");
        }

        // HR DASHBOARD (Separate Page: Process Payments & Generate Reports)
        [Authorize(Roles = "HR")]
        public async Task<IActionResult> HR()
        {
            var readyClaims = await _context.Claims.Where(c => c.Status == "PM Approved").ToListAsync();
            ViewBag.TotalPending = readyClaims.Sum(c => c.TotalAmount);
            return View(readyClaims);
        }

        [HttpPost]
        [Authorize(Roles = "HR")]
        public async Task<IActionResult> ProcessPayment(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null) return NotFound();

            claim.Status = "Paid";
            claim.ApprovalNote += "\nHR: Payment processed & invoice generated.";
            await _context.SaveChangesAsync();

            // Simple report generation (in real app, use SSRS or PDF lib)
            TempData["Success"] = $"Payment processed: R{claim.TotalAmount:F2}";
            return RedirectToAction("HR");
        }

        public async Task<IActionResult> GenerateReport()
        {
            var paidClaims = await _context.Claims.Where(c => c.Status == "Paid").ToListAsync();
            // Output: Neat table in view or download CSV/PDF
            return View(paidClaims); // Separate report view
        }
    }
}
