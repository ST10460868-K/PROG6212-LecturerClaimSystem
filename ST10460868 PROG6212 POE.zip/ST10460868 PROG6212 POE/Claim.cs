﻿using System.ComponentModel.DataAnnotations;

namespace ContractClaimSystem.Models
{
    public class Claim
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Lecturer name is required")]
        public string LecturerName { get; set; } = string.Empty;

        [Range(1, 160, ErrorMessage = "Hours must be 1-160")]
        public decimal HoursWorked { get; set; }

        [Range(100, 1000, ErrorMessage = "Rate must be R100-R1000")]
        public decimal RatePerHour { get; set; }

        public decimal TotalAmount => HoursWorked * RatePerHour; // AUTO-CALCULATED

        public string Status { get; set; } = "Pending"; // Pending, PC Approved, PM Approved, Paid
        public DateTime SubmittedDate { get; set; } = DateTime.Now;
        public string[] Documents { get; set; } = Array.Empty<string>(); // File names
        public string Notes { get; set; } = string.Empty;
        public string ApprovalNote { get; set; } = string.Empty;
    }
}