using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using ClaimSystem.Models;
using ClaimSystem.Services;

namespace ClaimSystem
{
    public partial class MainWindow : Window
    {
        private readonly ClaimService _claimService = new ClaimService();
        private readonly FileUploadService _fileService = new FileUploadService();
        private Claim _claim = new Claim();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _claim.LecturerName = txtLecturerName.Text;
                _claim.HoursWorked = double.Parse(txtHoursWorked.Text);
                _claim.RatePerHour = double.Parse(txtRatePerHour.Text);

                _claim.TotalAmount = _claimService.CalculateTotal(_claim.HoursWorked, _claim.RatePerHour);
                txtTotal.Text = $"Total Claim: R{_claim.TotalAmount:F2}";
            }
            catch
            {
                MessageBox.Show("Please ensure all inputs are numeric and not empty.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog
            {
                Filter = "Documents (*.pdf;*.docx;*.png;*.jpg)|*.pdf;*.docx;*.png;*.jpg"
            };

            if (dialog.ShowDialog() == true)
            {
                string result = _fileService.UploadFile(dialog.FileName);
                txtFilePath.Text = result;
            }
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLecturerName.Text) || string.IsNullOrWhiteSpace(txtHoursWorked.Text))
            {
                MessageBox.Show("Please fill in all fields before submitting.", "Missing Data", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _claim.Status = ((ComboBoxItem)cmbStatus.SelectedItem)?.Content.ToString() ?? "Draft";
            _claimService.SaveClaim(_claim);
            txtResult.Text = $"Claim submitted successfully! Status: {_claim.Status}";
        }
    }
}
