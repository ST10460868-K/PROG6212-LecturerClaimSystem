using System;
using System.IO;

namespace ClaimSystem.Services
{
    public class FileUploadService
    {
        private readonly string uploadDir = "uploads";

        public FileUploadService()
        {
            if (!Directory.Exists(uploadDir))
                Directory.CreateDirectory(uploadDir);
        }

        public string UploadFile(string sourcePath)
        {
            try
            {
                string fileName = Path.GetFileName(sourcePath);
                string destinationPath = Path.Combine(uploadDir, fileName);
                File.Copy(sourcePath, destinationPath, true);
                return $"File uploaded: {fileName}";
            }
            catch (Exception ex)
            {
                return $"Upload failed: {ex.Message}";
            }
        }
    }
}
