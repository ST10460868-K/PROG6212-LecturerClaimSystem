using System;
using System.IO;
using ClaimSystem.Models;

namespace ClaimSystem.Services
{
    public class ClaimService
    {
        private readonly string filePath = "claims.txt";

        public double CalculateTotal(double hours, double rate)
        {
            return Math.Round(hours * rate, 2);
        }

        public void SaveClaim(Claim claim)
        {
            string record = $"{DateTime.Now} | {claim.LecturerName} | {claim.HoursWorked} | {claim.RatePerHour} | {claim.TotalAmount} | {claim.Status}";
            File.AppendAllText(filePath, record + Environment.NewLine);
        }
    }
}
