namespace ClaimSystem.Models
{
    public class Claim
    {
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double RatePerHour { get; set; }
        public double TotalAmount { get; set; }
        public string Status { get; set; }
    }
}
