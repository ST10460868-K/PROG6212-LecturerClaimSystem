using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClaimSystem.Services;

namespace ClaimSystem.Tests
{
    [TestClass]
    public class ClaimServiceTests
    {
        [TestMethod]
        public void CalculateTotal_ShouldReturnCorrectAmount()
        {
            // Arrange
            ClaimService service = new ClaimService();
            double hours = 10;
            double rate = 200;

            // Act
            double result = service.CalculateTotal(hours, rate);

            // Assert
            Assert.AreEqual(2000, result);
        }
    }
}
